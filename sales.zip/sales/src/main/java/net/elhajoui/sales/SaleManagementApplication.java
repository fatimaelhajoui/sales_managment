package net.elhajoui.sales;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class SaleManagementApplication {

	public static void main(String[] args) {
		SpringApplication.run(SaleManagementApplication.class, args);
	}

}
